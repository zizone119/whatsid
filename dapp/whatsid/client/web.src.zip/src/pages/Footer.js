import '../css/footer.css'

const Footer = () => {
    return (
        <footer>
            <hr />            
            <div className="footer"> copyright ---- </div>             
        </footer>
    )
}
export default Footer;