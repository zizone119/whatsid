import java.util.Scanner;
import java.util.Vector;

class User {
	public static int cnt=0; 
	String name;
	int type, num;

	public User(String name, int type, int num) {
		super();
		this.name = name;
		this.type = type;
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}

class Seat {
	String[] seatS = new String[10];
	String[] seatA = new String[10];
	String[] seatB = new String[10];

	public String[] getSeatS() {
		return seatS;
	}

	public void setSeatS(String[] seatS) {
		this.seatS = seatS;
	}

	public String[] getSeatA() {
		return seatA;
	}

	public void setSeatA(String[] seatA) {
		this.seatA = seatA;
	}

	public String[] getSeatB() {
		return seatB;
	}

	public void setSeatB(String[] seatB) {
		this.seatB = seatB;
	}

	
}

public class Reservation {
	Vector<User> user = new Vector<User>();
	Seat seat = new Seat();
	boolean flag = false;
	Scanner sc = new Scanner(System.in);
	
	private void reserve() {
		while (true) {
			System.out.print("좌석 구분 S(1),A(2),B(3),뒤로가기(0) >> ");
			int n = 0;
			String t=sc.next();
			try {
				n=Integer.parseInt(t);
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			String[] tmp;
			if (n == 1)
				tmp = this.seat.getSeatS();
			else if (n == 2)
				tmp = this.seat.getSeatA();
			else if (n == 3)
				tmp = this.seat.getSeatB();
			else if (n == 0) {
				break;
			} else
				continue;
			for (int i = 0; i < tmp.length; i++) {
				if (tmp[i] == null)
					System.out.print("--- ");
				else
					System.out.print(tmp[i]+" ");
			}
			System.out.println();
			System.out.print("이름 >> ");
			String name = sc.next();
			if(name.equals("")) continue;
			System.out.println("번호 >> ");
			while (true) {
				int num=0;
				t = sc.next();
				if(t==null) break;
				try {
					num=Integer.parseInt(t);
				}catch (Exception e) {
					// TODO: handle exception
				}
				
				if (num < 0 || n > 10 || tmp[num] != null) {
					System.out.println("예약 가능한 번호를 입력하세요.");
					continue;
				} else {
					tmp[num] = name;
					if(n==1) this.seat.setSeatS(tmp);
					if(n==2) this.seat.setSeatA(tmp);
					if(n==3) this.seat.setSeatB(tmp);
					user.add(new User(name, n, num));
					break;
				}
			}
			System.out.println("예약이 완료되었습니다.");
			User.cnt++;
			break;
		}
	}

	private void check() {
		String[] tmp = this.seat.getSeatS();
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i] == null)
				System.out.print("--- ");
			else
				System.out.print(tmp[i]+" ");
		}
		System.out.println();
		tmp = this.seat.getSeatA();
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i] == null)
				System.out.print("--- ");
			else
				System.out.print(tmp[i]+" ");
		}
		System.out.println();
		tmp = this.seat.getSeatB();
		for (int i = 0; i < tmp.length; i++) {
			if (tmp[i] == null)
				System.out.print("--- ");
			else
				System.out.print(tmp[i]+" ");
		}
		System.out.println();
		System.out.println("현재 예약 인원 : " + User.cnt+", 예약 가능 인원 : "+(30-User.cnt));
		System.out.println("\n조회를 완료하였습니다.");
	}

	private void cancel() {
		while (true) {
			System.out.print("좌석 구분 S(1),A(2),B(3),뒤로가기(0) >> ");
			Scanner sc2 = new Scanner(System.in);
			int n = 0;
			try{
				n = sc2.nextInt();
			}catch (Exception e) {
				System.out.println("숫자를 입력하세요.");
			}
			String[] tmp;
			if (n == 1)
				tmp = this.seat.getSeatS();
			else if (n == 2)
				tmp = this.seat.getSeatA();
			else if (n == 3)
				tmp = this.seat.getSeatB();
			else if (n == 0) {
				break;
			} else
				continue;
			for (int i = 0; i < tmp.length; i++) {
				if (tmp[i] == null)
					System.out.print("--- ");
				else
					System.out.print(tmp[i]+" ");
			}
			System.out.println();
			while (true) {
				System.out.print("이름 >> ");
				String name = sc2.next();
				if(name==null) break;
				boolean flag=true;
				for(int i=0;i<this.user.size();i++) {
					User man = this.user.get(i);
					if(man.getName().equals(name)&&man.getType()==n) {
						int manSeat=man.getNum();
						flag=false;
						if(n==1) {
							tmp = this.seat.getSeatS();
							tmp[manSeat]=null;
							this.seat.setSeatS(tmp);
						}
						else if(n==2) {
							tmp = this.seat.getSeatA();
							tmp[manSeat]=null;
							this.seat.setSeatA(tmp);
						}
						else if(n==3) {
							tmp = this.seat.getSeatB();
							tmp[manSeat]=null;
							this.seat.setSeatB(tmp);
						}
						this.user.remove(man);
						User.cnt--;
						System.out.println("취소가 완료되었습니다.");
						break;
					}
				}
				if(flag) {
					System.out.println("이름을 찾을 수 없습니다.");
					break;
				}
				break;
			}
			break;
		}
	}

	private void end() {
		System.out.println("명품 콘서트 예약 시스템을 종료합니다.");
		this.flag = true;
	}

	private void run() {
		
		System.out.println("명품 콘서트 예약 시스템입니다.");
		while (true) {
			System.out.print("예약:1, 조회:2, 취소:3, 끝내기:4 >> ");
			Scanner sc1 = new Scanner(System.in);
			int a=0;
			try{
				a = sc1.nextInt();
			}catch (Exception e) {
				System.out.println("숫자를 입력하세요.");
				continue;
			}
			switch (a) {
			case 1:
				this.reserve();
				break;
			case 2:
				this.check();
				break;
			case 3:
				this.cancel();
				break;
			case 4:
				this.end();
				break;
			default:
				break;
			}
			if (flag)
				break;
		}
	}

	public static void main(String[] args) {
		new Reservation().run();
	}

}
