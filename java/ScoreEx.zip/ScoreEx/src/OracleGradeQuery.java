
public class OracleGradeQuery {

}
